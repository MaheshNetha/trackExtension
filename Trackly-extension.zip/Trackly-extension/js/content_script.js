
//htmlChangeTrig();

$(document).ready(function(){
    //initContent();
    urlChangeTrig();

})
$.ctrl('B', function() {
    initContent();
});