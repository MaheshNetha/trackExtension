//this extention created by ----> fadyAyoobDev@gmail.com
laodConfigBackGround();


setInterval(function(){
    laodConfigBackGround();
},60*1000); // 1 min