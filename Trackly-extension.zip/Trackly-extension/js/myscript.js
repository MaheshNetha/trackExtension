//this extention created by ----> fadyAyoobDev@gmail.com
var i=0;
var selectedProjectsArrayList = [];

String.prototype.replaceAll = function(search, replacement) {
    var target = this;
    return target.replace(new RegExp(search, 'g'), replacement);
};

function login(user,pass){
    loader(1);
    var http = new XMLHttpRequest();
    var url = "https://tracklynew.appup.cloud/trackly/loginpage";
    var params = "email="+user+"&password="+pass;
    http.open("POST", url, true);

    //Send the proper header information along with the request
    http.setRequestHeader("Content-type", "application/x-www-form-urlencoded");

    http.onreadystatechange = function () {//Call a function when the state changes.
        if (http.readyState == 4 && http.status == 200) {
            res=http.responseText;
            res=JSON.parse(res)
           // alert(res);
            //console.log(res);
            key=res.token;
            console.log(key);
            localStorage.setItem('tokenValue',key);
            chrome.storage.local.set({key: key}, function() {});
            chrome.storage.local.set({login: 1}, function() {});
            laodConfig();

        }
        else if( http.readyState == 4 && http.status == 400){
            alert('wrong emnail or password ... please try again');
            loader(0);

        }
    }
    http.send(params);
    
    
}

function loader(state){
    if(state==0)//hide
    {
     $('.loader').hide();   
    }
    else if(state==1)//show
    {
     $('.loader').show();   
    }
}

function laodConfig(){
    
    var http = new XMLHttpRequest();
    var url = "https://tracklynew.appup.cloud/trackly/extension/getXpath";
    var params = "";
    http.open("GET", url, true);

    //Send the proper header information along with the request
    http.setRequestHeader("Content-type", "application/x-www-form-urlencoded");

    http.onreadystatechange = function () {//Call a function when the state changes.
        if (http.readyState == 4 && http.status == 200) {
            res=http.responseText;
          //  alert(res);
        //    console.log(res);
            loader(0);

            res=JSON.parse(res);

            chrome.storage.local.set({Config: res}, function() {
                
                LoginDone();
            });


        }
   
    }
    http.send(params);
}


function laodConfigBackGround(){
    
    var http = new XMLHttpRequest();
    var url = "https://tracklynew.appup.cloud/trackly/extension/getXpath";
    var params = "";
    http.open("GET", url, true);

    //Send the proper header information along with the request
    http.setRequestHeader("Content-type", "application/x-www-form-urlencoded");

    http.onreadystatechange = function () {//Call a function when the state changes.
        if (http.readyState == 4 && http.status == 200) {
            res=http.responseText;
         //   alert(res);
        //    console.log(res);
            res=JSON.parse(res);

            chrome.storage.local.set({Config: res}, function() {});


        }
   
    }
    http.send(params);
}

function logout(){
    chrome.storage.local.set({login: 0}, function() { location.reload(); });
    localStorage.clear();

}

function LoginDone(){
    $('.login').hide();
    $('.logged').show();
}


function initPopup(){
     chrome.storage.local.get('login', function (result) {
        loginState = result.login;
        if(loginState){
            $('.logged').show();

        }
         else{
             $('.login').show();

         }
    });
}


function initContent(){

    // var moment_include = document.createElement('script');
    // moment_include.src = "https://cdnjs.cloudflare.com/ajax/libs/moment.js/2.18.1/moment.js";
    // document.head.appendChild(moment_include);
    // var moment_js = document.createElement('script');
    // moment_js.src = "https://cdnjs.cloudflare.com/ajax/libs/moment-timezone/0.5.23/moment-timezone-with-data.min.js";
    // document.head.appendChild(moment_js);


    intLoop=setInterval(function(){
        
    
     chrome.storage.local.get('login', function (result) {
        loginState = result.login;
        if(loginState){
            chrome.storage.local.get('Config', function (result) {
                Config = result.Config;

                if(Config){
                    for(i=0;i<Config.length;i++){
                        
                        webdata=Config[i];
                        domain=document.domain;

                        if(domain.indexOf(webdata['site'])>=0){
                            console.log("SiteName----*****************------------------", document.domain);
                         //   alert('matched');
                            xpath=webdata['xpath'];
                            xpath_icon=webdata['xpath_icon'];
                            internalTasksPath = webdata['internalTasksPath'];

                          /*  xpath=xpath.replace("$x('",'');
                            xpath=xpath.replace("')",'');*/





                            webdata['callback_url']=webdata['callback_url'].replaceAll(' ','');
                            webdata['callback_url']=webdata['callback_url'].replace('http://','https://');
                            webdata['icon_url']=webdata['icon_url'].replace('http://','https://');
                            orignal_url=webdata['icon_url']


                            webdata['callback_url']=webdata['callback_url'].replaceAll("'",'"');


                            webdata['icon_url']=webdata['icon_url'].replaceAll("'",'"');
                            toggle_url=webdata['toggle_url']
                           // alert(toggle_url);
                            /*console.log( getElementByXpath(xpath) );

                            node=getElementByXpath(xpath);
                            console.log(node);
                            if(node){
                                node.innerHTML=node.innerHTML+'<a href='+webdata['callback_url']+' target="_blank" > <img src='+webdata['icon_url']+' /> </a>';

                                clearInterval(intLoop);
                            }*/
                            cssSelector_icon=XpathToCSS(xpath_icon);
                            cssSelector_text=XpathToCSS(xpath);
                            // cssSelector_tasks = XpathToCSS(internalTasksPath);


                          //  console.log(cssSelector);
                            $('.POSTMAN_chrome_extenstion').remove();
                           result= $(cssSelector_icon)//.after(' <img class="POSTMAN_chrome_extenstion"  src='+webdata['icon_url']+' "Pr_name"="'+$(this).innerTEXT+'" />');
                            result_text=$(cssSelector_text);
                            for(i=0;i<result.length;i++){
                                clearInterval(intLoop);

                                textCon=result_text[i].innerText;
                              //  alert(textCon);
                                result[i].innerHTML=result[i].innerHTML+(' <img class="POSTMAN_chrome_extenstion" style="cursor: pointer;" src="'+webdata['icon_url']+'"PrName="'+textCon+'" />');

                            }

                            // for internal tasks

                            // if(internalTasksPath) {
                            //     tasks = $(cssSelector_tasks);
                            //     textCon=tasks[i].innerText;
                            //     for(i=0; i<tasks.length; i++) {
                            //         clearInterval(intLoop);
                            //         tasks[i].innerHTML=tasks[i].innerHTML+(' <img class="POSTMAN_chrome_extenstion"  src="'+webdata['icon_url']+'" PrName="'+textCon+'" />');
                            //     }
                            // }


                         //   console.log(result);

                            $('.POSTMAN_chrome_extenstion').click(function(){
                               Pr_name= $(this).attr("PrName");
                                if($(this).attr('src')!=toggle_url){
                                    // $(this).attr('src', toggle_url);
                                    this.setAttribute('src',toggle_url);
                                        fromTimeDateObj = new Date();
                                        fromTimeDuration= new Date(fromTimeDateObj.getTime());
                                        fromTime= dateFormat(fromTimeDateObj);
                                        arrayObj = {
                                            "projectName":Pr_name,
                                            "fromTime":fromTime,
                                            "formTimeDateObj":fromTimeDuration
                                        };

                                        selectedProjectsArrayList.push(arrayObj);


                                        // internal tasks and project name/sprint name for basecamp

                                        cssSelector_tasks = XpathToCSS(internalTasksPath,Pr_name);





                                    // moment(fromTime).format('YYYY-MM-DD'+' '+'HH:MM:SS');
                                    return false;
                                }
                                else{
                                    // $(this).attr('src', orignal_url);
                                    this.setAttribute('src',orignal_url);
                                    var stopTimeObj = new Date();
                                        toTime      = dateFormat(stopTimeObj);

                                    // internal tasks and project name/sprint name for basecamp
                                        cssSelector_tasks = XpathToCSS(internalTasksPath,Pr_name);

                                        for(i=0; i<selectedProjectsArrayList.length;i++) {
                                                if(selectedProjectsArrayList[i].projectName == Pr_name) {
                                                    fromTime = selectedProjectsArrayList[i].fromTime;
                                                    fromTimeDuration = selectedProjectsArrayList[i].formTimeDateObj;
                                                }

                                        }

                                        if(fromTime && toTime) {
                                            var postData = {
                                                "from_time" : fromTime,
                                                "to_time": toTime,
                                                "duration":Math.floor((stopTimeObj.getTime() - fromTimeDuration.getTime()) / (1000))
                                            };

                                            sendProject(Pr_name,postData);
                                        }

                                    return false;
                                }


                            });


                        }
                        
                    }
                }

            });
        }
         
    });
        
    },500);
}

function dateFormat(dateObj){

    if (dateObj.getMonth() < 10) {
        var month = '0' + (dateObj.getMonth() + 1);
    }
    var dateFormat = dateObj.getFullYear()+"-"+month+"-"+dateObj.getDate();
    var timeFormat = dateObj.getHours()+":"+dateObj.getMinutes()+":"+dateObj.getSeconds();
    var time   = dateFormat+" "+timeFormat;
    time.toString();
    return time
}

function XpathToCSS(xpath,Pr_name){
    var xpath = xpath.slice(4, xpath.length -2);
    console.log(xpath);
    if(Pr_name) {
         xpath = xpath.replace('projName',Pr_name)
    }
    xpath=xpath.replaceAll("'",'"');
    cssSelector=cssify(xpath);
    
    return cssSelector;

}

function getElementByXpath(path) {
  return document.evaluate(path, document, null, XPathResult.FIRST_ORDERED_NODE_TYPE, null).singleNodeValue;
}


$.ctrl = function(key, callback, args) {
    var isCtrl = false;
    $(document).keydown(function(e) {
        if(!args) args=[]; // IE barks when args is null
        
        if(e.ctrlKey) isCtrl = true;
        if(e.keyCode == key.charCodeAt(0) && isCtrl) {
            callback.apply(this, args);
            return false;
        }
    }).keyup(function(e) {
        if(e.ctrlKey) isCtrl = false;
    });        
};


function htmlChangeTrig(){
    oldhtml='';
    setInterval(function(){
        newhtml=document.getElementsByTagName('html')[0].innerHTML;
        if(newhtml!=oldhtml){
            oldhtml=document.getElementsByTagName('html')[0].innerHTML;
            initContent();
        }
    })
}


function urlChangeTrig(){
    oldURL='';
    setInterval(function(){
        newURL=document.URL;
        if(newURL!=oldURL){
            oldURL=document.URL;
            initContent();
        }
    },500);
}



function sendProject(project_name,postData){
    debugger;

    var http = new XMLHttpRequest();
    var url = "https://tracklynew.appup.cloud/trackly/creating/project";
    var params = "project_name="+project_name+
                 "&from_time="+postData.from_time+
                 "&to_time="+postData.to_time+
                 "&duration="+postData.duration+
                 "&date="+postData.to_time;

    var dynamicTokenValue = localStorage.getItem('tokenValue');

    http.open("POST", url, true);


    //Send the proper header information along with the request
    http.setRequestHeader("Content-type", "application/x-www-form-urlencoded");

    chrome.storage.local.get('key', function (result) {
        http.setRequestHeader("token", result.key);
        console.log('sfsd42342342423423',result.key);


        //Call a function when the state changes
        http.onreadystatechange = function () {
            if (http.readyState == 4 && http.status == 200) {
                res=http.responseText;
                alert('The Project is added ');


                //console.log(res);
                //  res=JSON.parse(res);
            }

        };
        http.send(params);
    });



}


