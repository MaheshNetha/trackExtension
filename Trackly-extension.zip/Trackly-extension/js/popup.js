//this extention created by ----> fadyAyoobDev@gmail.com


initPopup();

$(document).ready(function(){
    

    
    $('#loginform').submit(function(){
        user=document.getElementById('email').value;
        pass=document.getElementById('pswd').value;
        login(user,pass); 
    });
    
    
    $('#logout').click(function(){
      logout();
    });

});
